package ia_MVC;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
//import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import ia.Stockfish;
import pieces.GamePieceBoard;
import pieces.PieceColor;


public class Controller {
	
	private Model gameModel;
	private View gameView;
	private GamePieceBoard[][] gamePieceBoard;
	private JLabel[][] gameBoardLabels;
	private boolean selectedPiece;
	private int tmpRow, tmpCol;
	private GamePieceBoard tmpPiece;
	private PieceColor playerTurn;
	private int blackWins, whiteWins;
	private Stockfish stockfish;
	private Stockfish bmstockfish; //Only used to get the best move
	private String bestmove;
	private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
	//private int rndMoveCounter;
	//private int stdifficulty;
	

	public Controller(Model gameModel, View gameView, String difficulty) {
		
		this.gameModel = gameModel;
		this.gameView = gameView;
		gamePieceBoard = gameModel.getGamePieceBoard();
		gameBoardLabels = gameView.getGameBoardLabels();
		selectedPiece = false;
		updatePlayerTurn();
		blackWins = 0;
		whiteWins = 0;
		stockfish = new Stockfish();
		bmstockfish = new Stockfish();
		stockfish.startEngine();
		bmstockfish.startEngine();
		System.out.println(stockfish.setDifficuly(difficulty));
		//stdifficulty= Integer.parseInt(difficulty);
		//rndMoveCounter=0;
		
		this.gameView.updateGUI(gamePieceBoard, playerTurn, blackWins, whiteWins);

		this.gameView.addMouseListener(new MouseHandler());
	}

	
	private class MouseHandler implements MouseListener {

		public void mouseClicked(MouseEvent arg) {
		}

		public void mouseEntered(MouseEvent arg) {
		}

		public void mouseExited(MouseEvent arg) {
		}

		public void mousePressed(MouseEvent arg) {

			for(int i = 0; i < 8; i++) {
				for(int j = 0; j < 8; j++) {
					
					// Finds the Label that has been clicked
					if(gameBoardLabels[i][j] == arg.getSource()) {
						
						if(selectedPiece && tmpPiece != null) {	// SECOND CLICK to move the piece
							turnmanage(i, j, tmpPiece);
								
						}else {	// Selects the clicked piece
							selectedPiece = true;
							tmpRow = i;
							tmpCol = j;
							tmpPiece = gamePieceBoard[i][j];
							
							gameView.highlightSelectedLabel(i, j, Color.yellow);
						}
					}					
				}
			}
			
			// Resets the game if "Reset" is clicked.
			if(arg.getSource() == gameBoardLabels[8][0]|| arg.getSource() ==gameBoardLabels[8][1]) {
				gameModel.resetGame();
				updatePlayerTurn();
				gameView.updateGUI(gamePieceBoard, playerTurn, blackWins, whiteWins);
			}

			// Highlits the piece you should move if "Hint" is clicked.
			if(arg.getSource() == gameBoardLabels[8][6]){
				String FEN= gameModel.getFEN();
				bestmove=bmstockfish.getBestMove(FEN, 100);
				String[] s = bestmove.split("");
				gameView.highlightSelectedLabel(Integer.parseInt(s[1]), Integer.parseInt(s[0]),Color.green);
			}
			// Highlits the squares of the best move when "best move" is clicked.
			if(arg.getSource() == gameBoardLabels[8][7]){
				String FEN= gameModel.getFEN();
				bestmove=bmstockfish.getBestMove(FEN, 100);
				String[] s = bestmove.split("");
				gameView.highlightSelectedLabel(Integer.parseInt(s[1]), Integer.parseInt(s[0]),Color.magenta);
				gameView.highlightSelectedLabel(Integer.parseInt(s[3]), Integer.parseInt(s[2]),Color.magenta);
				 
    			scheduler.schedule(() -> { // Wait two seconds and unhighlit the square
        		gameView.unHighlightSelectedLabel(Integer.parseInt(s[3]), Integer.parseInt(s[2]));
    			}, 2, TimeUnit.SECONDS);
			}

            if(gameModel.getPlayerTurn()==PieceColor.BLACK)
				iaturn(); 
		}

		public void mouseReleased(MouseEvent arg) {
		}
	}

	public void turnmanage(int sRow, int sCol, GamePieceBoard tmpPiece){
		// Attempts to advance game by moving the selected piece
							if(gameModel.movePieceAttempt(tmpRow, tmpCol, sRow, sCol, tmpPiece)) {
								System.out.println("Se mueve pieza "+tmpPiece.getFENRepresentation()+
								tmpRow+""+tmpCol+" a "+sRow+""+sCol);
								updatePlayerTurn();
								gameView.updateGUI(gamePieceBoard, playerTurn, blackWins, whiteWins);
							}
							
							gameView.unHighlightSelectedLabel(tmpRow, tmpCol);
							selectedPiece = false;
							
							// Checks for GAMEOVER
							if(gameModel.isGameOver()) {
								PieceColor winner = PieceColor.BLACK;
								
								if(playerTurn == PieceColor.BLACK) {
									winner = PieceColor.WHITE;
									whiteWins++;
								} else
									blackWins++;
								
								JOptionPane.showMessageDialog(null,
								"Congratulations " + winner + ", you win!",
									    "WINNER!!!",
									    JOptionPane.PLAIN_MESSAGE);
								
								gameModel.resetGame();
								updatePlayerTurn();
								stockfish.stopEngine();
								gameView.updateGUI(gamePieceBoard, playerTurn, blackWins, whiteWins);
							}


	}

	public void iaturn(){
		System.out.println("FEN:   "+gameModel.getFEN());
		String bestmove= stockfish.getBestMove(gameModel.getFEN(), 100);
		System.out.println("best move: "+bestmove+"  ");
		String[] s = bestmove.split("");
		tmpCol= Integer.parseInt(s[0]);
		tmpRow= Integer.parseInt(s[1]);
		int dCol= Integer.parseInt(s[2]);
		int dRow= Integer.parseInt(s[3]);
		gamePieceBoard= gameModel.getGamePieceBoard();
		scheduler.schedule(() -> { // Wait one second and then do the best move
        		turnmanage(dRow,dCol,gamePieceBoard[tmpRow][tmpCol]);
    			}, 1, TimeUnit.SECONDS);
	}

	/* Updates the playerTurn to send to GUI */
	public void updatePlayerTurn() {
		playerTurn = gameModel.getPlayerTurn();
	}

	/*public void iaturn(){
		if(rndMoveCounter>=stdifficulty){
			rndMoveCounter=0;
			Random rnd = new Random();
			int sRow= rnd.nextInt(8);
			int sCol= rnd.nextInt(8);
			int dRow= rnd.nextInt(8);
			int dCol= rnd.nextInt(8); 
				while(gamePieceBoard[sRow][sCol]!=null && gamePieceBoard[sRow][sCol].getColor()==PieceColor.BLACK
				&& gameModel.movePieceAttempt(sRow, sCol, dRow, dCol,gamePieceBoard[sRow][sCol])){
					sRow= rnd.nextInt(8);
					sCol= rnd.nextInt(8);
					dRow= rnd.nextInt(8);
					dCol= rnd.nextInt(8); 
				}

				System.out.println("Se mueve pieza "+tmpPiece.getFENRepresentation()+
					tmpRow+""+tmpCol+" a "+sRow+""+sCol);
				updatePlayerTurn();
				//scheduler.schedule(() -> { // Wait one second and then update the GUI
        		gameView.updateGUI(gamePieceBoard, playerTurn, blackWins, whiteWins);
    			//}, 1, TimeUnit.SECONDS);

		}
		else{
			rndMoveCounter++;
			System.out.println("FEN:   "+gameModel.getFEN());
			String bestmove= stockfish.getBestMove(gameModel.getFEN(), 100);
			System.out.println("best move: "+bestmove+"  ");
			String[] s = bestmove.split("");
			tmpCol= Integer.parseInt(s[0]);
			tmpRow= Integer.parseInt(s[1]);
			int dCol= Integer.parseInt(s[2]);
			int dRow= Integer.parseInt(s[3]);
			gamePieceBoard= gameModel.getGamePieceBoard();
			scheduler.schedule(() -> { // Wait one second and then do the best move
        		turnmanage(dRow,dCol,gamePieceBoard[tmpRow][tmpCol]);
    			}, 1, TimeUnit.SECONDS);
		}
	}/* */

}