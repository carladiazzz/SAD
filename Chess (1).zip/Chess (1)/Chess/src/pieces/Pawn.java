package pieces;

public class Pawn extends GamePieceBoard {

	public Pawn(PieceColor color) {
		super(color);
	}

	@Override
	protected boolean isLegalPieceMove(int sRow, int sCol, int dRow, int dCol, GamePieceBoard[][] gamePieceBoard) {
		    // Verifica que las coordenadas estén dentro del rango del tablero
			if (sRow < 0 || sRow >= gamePieceBoard.length || sCol < 0 || sCol >= gamePieceBoard[0].length ||
			dRow < 0 || dRow >= gamePieceBoard.length || dCol < 0 || dCol >= gamePieceBoard[0].length) {
			return false;
		}
	
		// Verifica que el movimiento sea hacia adelante (dependiendo del color del peón)
		if (gamePieceBoard[sRow][sCol].getColor() == PieceColor.WHITE) {
			// Movimiento estándar hacia adelante
			if (dRow == sRow - 1 && dCol == sCol && gamePieceBoard[dRow][dCol] == null) {
				return true;
			}
			// Doble paso inicial
			else if (sRow == 6 && dRow == sRow - 2 && dCol == sCol && gamePieceBoard[dRow][dCol] == null) {
				return true;
			}
			// Captura diagonal
			else if (dRow == sRow - 1 && Math.abs(dCol - sCol) == 1 &&
					gamePieceBoard[dRow][dCol] != null && gamePieceBoard[dRow][dCol].getColor() == PieceColor.BLACK) {
				return true;
			}
		} else if (gamePieceBoard[sRow][sCol].getColor() == PieceColor.BLACK) {
			// Movimiento estándar hacia adelante
			if (dRow == sRow + 1 && dCol == sCol && gamePieceBoard[dRow][dCol] == null) {
				return true;
			}
			// Doble paso inicial
			else if (sRow == 1 && dRow == sRow + 2 && dCol == sCol && gamePieceBoard[dRow][dCol] == null) {
				return true;
			}
			// Captura diagonal
			else if (dRow == sRow + 1 && Math.abs(dCol - sCol) == 1 &&
					gamePieceBoard[dRow][dCol] != null && gamePieceBoard[dRow][dCol].getColor() == PieceColor.WHITE) {
				return true;
			}
		}
	
		return false;
	}

	@Override
	public Piece getName() {
		return Piece.PAWN;
	}
}