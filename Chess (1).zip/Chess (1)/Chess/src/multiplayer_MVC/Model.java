package multiplayer_MVC;

import gameboard.GameBoard;
import pieces.GamePieceBoard;
import pieces.Piece;
import pieces.PieceColor;

public class Model {

	private GameBoard board;
	private GamePieceBoard[][] gamePieceBoard;
	private PieceColor playerTurn;
	
	public Model() {
		setBoard(new GameBoard());
		gamePieceBoard = board.getBoard();
		playerTurn = PieceColor.WHITE;
	}

	//Tries to move a GamePiece and returns true if it's possible
	public boolean movePieceAttempt(int sRow, int sCol, int dRow, int dCol, GamePieceBoard piece) {
		
		if(piece.isLegalMove(sRow, sCol, dRow, dCol, gamePieceBoard) && piece.getColor() == playerTurn) {
			// Advance game
			gamePieceBoard[dRow][dCol] = gamePieceBoard[sRow][sCol];
			gamePieceBoard[sRow][sCol] = null;
			changePlayerTurn();
			return true;
		}		
		
		return false;
	}
	
	//Reset Game to starting position 
	public void resetGame() {
		playerTurn = PieceColor.WHITE;
		board.resetBoard();
	}
	
	// Changes playerTurn using PieceColor enum 
	public void changePlayerTurn() {
		if(playerTurn == PieceColor.WHITE)
			playerTurn = PieceColor.BLACK;
		else
			playerTurn = PieceColor.WHITE;
	}
	
	// Checks if game is over 
	public boolean isGameOver() {
		int count = 0;
		
		for(int i = 0; i < 8; i++)
			for(int j = 0; j < 8; j++)
				if(gamePieceBoard[i][j] != null && gamePieceBoard[i][j].getName() == Piece.KING)
					count++;
		
		if(count != 2)
			return true;
		
		return false;
	}
	
	public GameBoard getBoard() {
		return board;
	}

	public void setBoard(GameBoard board) {
		this.board = board;
	}
	
	public GamePieceBoard[][] getGamePieceBoard() {
		return board.getBoard();
	}
	
	public PieceColor getPlayerTurn() {
		return playerTurn;
	}
}