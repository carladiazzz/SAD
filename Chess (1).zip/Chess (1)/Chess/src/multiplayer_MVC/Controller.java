package multiplayer_MVC;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import ia.Stockfish;
import pieces.GamePieceBoard;
import pieces.PieceColor;


public class Controller {
	
	private Model gameModel;
	private View gameView;
	private GamePieceBoard[][] gamePieceBoard;
	private JLabel[][] gameBoardLabels;
	private boolean selectedPiece;
	private int tmpRow, tmpCol;
	private GamePieceBoard tmpPiece;
	private PieceColor playerTurn;
	private int blackWins, whiteWins;
	private Stockfish stockfish;
	//private Stockfish bmstockfish; //Only used to get the best move
	//private String bestmove;
	//private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
	//private int rndMoveCounter;
	//private int stdifficulty;
	

	public Controller(Model gameModel, View gameView) {
		
		this.gameModel = gameModel;
		this.gameView = gameView;
		gamePieceBoard = gameModel.getGamePieceBoard();
		gameBoardLabels = gameView.getGameBoardLabels();
		selectedPiece = false;
		updatePlayerTurn();
		blackWins = 0;
		whiteWins = 0;
		//stockfish = new Stockfish();
		//stockfish.startEngine();
		//stdifficulty= Integer.parseInt(difficulty);
		//rndMoveCounter=0;
		
		this.gameView.updateGUI(gamePieceBoard, playerTurn, blackWins, whiteWins);

		this.gameView.addMouseListener(new MouseHandler());
	}

	
	private class MouseHandler implements MouseListener {

		public void mouseClicked(MouseEvent arg) {
		}

		public void mouseEntered(MouseEvent arg) {
		}

		public void mouseExited(MouseEvent arg) {
		}

		public void mousePressed(MouseEvent arg) {

			for(int i = 0; i < 8; i++) {
				for(int j = 0; j < 8; j++) {
					
					// Finds the Label that has been clicked
					if(gameBoardLabels[i][j] == arg.getSource()) {
						
						if(selectedPiece && tmpPiece != null) {	// SECOND CLICK to move the piece
							turnmanage(i, j, tmpPiece);
								
						}else {	// Selects the clicked piece
							selectedPiece = true;
							tmpRow = i;
							tmpCol = j;
							tmpPiece = gamePieceBoard[i][j];
							
							gameView.highlightSelectedLabel(i, j, Color.yellow);
						}
					}					
				}
			}
			
			// Resets the game if "Reset" is clicked.
			if(arg.getSource() == gameBoardLabels[8][0]|| arg.getSource() ==gameBoardLabels[8][1]) {
				gameModel.resetGame();
				updatePlayerTurn();
				gameView.updateGUI(gamePieceBoard, playerTurn, blackWins, whiteWins);
			}
			}
		

		public void mouseReleased(MouseEvent arg) {
		}
	}

	public void turnmanage(int sRow, int sCol, GamePieceBoard tmpPiece){
		// Attempts to advance game by moving the selected piece
							if(gameModel.movePieceAttempt(tmpRow, tmpCol, sRow, sCol, tmpPiece)) {
								System.out.println(tmpRow+""+tmpCol+""+sRow+""+sCol);
								updatePlayerTurn();
								gameView.updateGUI(gamePieceBoard, playerTurn, blackWins, whiteWins);
							}
							
							gameView.unHighlightSelectedLabel(tmpRow, tmpCol);
							selectedPiece = false;
							
							// Checks for GAMEOVER
							if(gameModel.isGameOver()) {
								PieceColor winner = PieceColor.BLACK;
								
								if(playerTurn == PieceColor.BLACK) {
									winner = PieceColor.WHITE;
									whiteWins++;
								} else
									blackWins++;
								
								JOptionPane.showMessageDialog(null,
								"Congratulations " + winner + ", you win!",
									    "WINNER!!!",
									    JOptionPane.PLAIN_MESSAGE);
								
								gameModel.resetGame();
								updatePlayerTurn();
								stockfish.stopEngine();
								gameView.updateGUI(gamePieceBoard, playerTurn, blackWins, whiteWins);
							}


	}

	public void otherPlayerMoves(String move){
			String[] s = move.split("");
			tmpCol= Integer.parseInt(s[0]);
			tmpRow= Integer.parseInt(s[1]);
			int dCol= Integer.parseInt(s[2]);
			int dRow= Integer.parseInt(s[3]);
			gamePieceBoard= gameModel.getGamePieceBoard();
			turnmanage(dRow,dCol,gamePieceBoard[tmpRow][tmpCol]);
		}

	/* Updates the playerTurn to send to GUI */
	public void updatePlayerTurn() {
		playerTurn = gameModel.getPlayerTurn();
	}
}

