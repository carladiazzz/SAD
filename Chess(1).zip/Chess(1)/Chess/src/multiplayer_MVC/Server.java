package multiplayer_MVC;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class Server {
    private static ConcurrentHashMap<String, MySocket> usuaris = new ConcurrentHashMap<>();
	
	public static void main(String[] args){

		MyServerSocket ss = new MyServerSocket(5000);
		System.out.println("Servidor inciat.");

		while(true){
			MySocket client = ss.accept();

			new Thread(){
				public void run(){
					client.write("Introdueix el teu nick: ");
					String nick = client.readLine();
					Main m = new Main();
                    m.run();
					addUsuari(nick, client);
					String movimiento;
					while((movimiento = client.readLine()) != null){
						broadcast(movimiento, nick);
						System.out.println(movimiento);
					}
					removeUsuari(nick);
					client.close();
				}
			}.start();
		}
	}


	public static void addUsuari(String usuari, MySocket s){
		System.out.println(usuari+" ha entrat al xat");
		usuaris.put(usuari, s);
	}


	public static void removeUsuari(String usuari){
		System.out.println(usuari+" ha sortit del xat");
		usuaris.remove(usuari);
	}


	public static void broadcast(String missatge, String nick){
		MySocket client= usuaris.get(nick);
		/*Iterator iterator = usuaris.entrySet().iterator();
		while (iterator.hasNext()) {
    		Map.Entry entry = (Map.Entry) iterator.next();
    			if(nick== entry.getKey())
					client.write(nick+"> "+missatge);
		}*/
		for (Map.Entry<String, MySocket> entry : usuaris.entrySet()) {
            String usuarioActual = entry.getKey();
            MySocket socketActual = entry.getValue();
			if(usuarioActual!=nick){
				socketActual.write(nick+"> "+missatge);
			}
		}
	}
    
}
