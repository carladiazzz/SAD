package gameboard;

import pieces.Bishop;
import pieces.GamePieceBoard;
import pieces.King;
import pieces.Knight;
import pieces.Pawn;
import pieces.PieceColor;
import pieces.Queen;
import pieces.Rook;

public class GameBoard {

	private GamePieceBoard[][] board;
	

	public GameBoard() {
		setBoard(new GamePieceBoard[8][8]);
		resetBoard();
	}
	
	//Initializes the game board 
	public void initializeBoard() {
		for(int i = 0; i < 8; i++)
			for(int j = 0; j < 8; j++)
				board[i][j] = null;
	}
	
	// Resets the gameBoard pieces to starting positions 
	public void resetBoard() {
		
		initializeBoard();
		
		// Allocate and position pieces
		for (int i = 0; i < 8; i++)
			board[1][i] = new Pawn(PieceColor.BLACK);

		board[0][0] = new Rook(PieceColor.BLACK);
		board[0][1] = new Knight(PieceColor.BLACK);
		board[0][2] = new Bishop(PieceColor.BLACK);
		board[0][3] = new King(PieceColor.BLACK);
		board[0][4] = new Queen(PieceColor.BLACK);
		board[0][5] = new Bishop(PieceColor.BLACK);
		board[0][6] = new Knight(PieceColor.BLACK);
		board[0][7] = new Rook(PieceColor.BLACK);
		
		for (int i = 0; i < 8; i++)
			board[6][i] = new Pawn(PieceColor.WHITE);
		
		board[7][0] = new Rook(PieceColor.WHITE);
		board[7][1] = new Knight(PieceColor.WHITE);
		board[7][2] = new Bishop(PieceColor.WHITE);
		board[7][3] = new King(PieceColor.WHITE);
		board[7][4] = new Queen(PieceColor.WHITE);
		board[7][5] = new Bishop(PieceColor.WHITE);
		board[7][6] = new Knight(PieceColor.WHITE);
		board[7][7] = new Rook(PieceColor.WHITE);
	}
	

	public GamePieceBoard[][] getBoard() {
		return board;
	}

	public void setBoard(GamePieceBoard[][] board) {
		this.board = board;
	}
}