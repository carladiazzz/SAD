package pieces;

public class Queen extends GamePieceBoard {

	public Queen(PieceColor color) {
		super(color);
	}

	@Override
	protected boolean isLegalPieceMove(int sRow, int sCol, int dRow, int dCol, GamePieceBoard[][] gamePieceBoard) {
		// Check if Queen movement is legal
		if (gamePieceBoard[sRow][sCol].isLegalLinearMove(sRow, sCol, dRow, dCol, gamePieceBoard) || gamePieceBoard[sRow][sCol].isLegalDiagonalMove(sRow, sCol, dRow, dCol, gamePieceBoard))
			return true;
		else
			return false;
	}

	@Override
	public Piece getName() {
		return Piece.QUEEN;
	}
}