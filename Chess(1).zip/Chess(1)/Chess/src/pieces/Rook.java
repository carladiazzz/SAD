package pieces;

public class Rook extends GamePieceBoard {

	public Rook(PieceColor color) {
		super(color);
	}

	@Override
	protected boolean isLegalPieceMove(int sRow, int sCol, int dRow, int dCol, GamePieceBoard[][] gamePieceBoard) {
		return gamePieceBoard[sRow][sCol].isLegalLinearMove(sRow, sCol, dRow, dCol, gamePieceBoard);
	}

	@Override
	public Piece getName() {
		return Piece.ROOK;
	}
}