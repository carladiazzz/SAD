package ia_MVC;

import pieces.GamePieceBoard;
import pieces.PieceColor;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import javax.swing.*;

public class View extends JFrame {
	
	/* Instantiate GUI related variables */
	private JPanel gamePanel;
	private GridLayout gameLayout;
	private JLabel[][] gameBoardLabels;
	
	/* Constructor */
	public View() {
		gamePanel = new JPanel();
		gameLayout = new GridLayout(9, 9);
		setgameBoardPieces(new JLabel[9][9]);
		initializeCheckeredBoard();
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(640, 720);
		this.setResizable(false);
		this.setTitle("Java Chess");
		gamePanel.setLayout(gameLayout);
		this.add(gamePanel);
	}
	
	// Creates & Colors in the Chess board(black & white checkered) 
	private void initializeCheckeredBoard() {

		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 8; j++) {
				JLabel label = getGameBoardLabels()[i][j] = new JLabel();
				label.setOpaque(true);
				
				if (i < 8 && j < 8) {
					if ((i % 2 == 0 && j % 2 == 0) || (i % 2 != 0 && j % 2 != 0)) {
						label.setBackground(Color.WHITE);
					} else {
						label.setBackground(Color.GRAY);
					}
				} else {
					label.setBackground(Color.getHSBColor(30f / 360f, 0.7f, 0.7f));
				}
				
				gamePanel.add(label);
			}
		}
		
		// Sets up the Reset Labels
		JLabel resetLabel = gameBoardLabels[8][0];
		resetLabel.setText("Reset ");
		resetLabel.setHorizontalAlignment(JLabel.RIGHT);
		JLabel resetLabel2 = gameBoardLabels[8][1];
		resetLabel2.setText("Game");
		resetLabel2.setHorizontalAlignment(JLabel.LEFT);

		JLabel hintLabel = gameBoardLabels[8][6];
		hintLabel.setText("Hint");
		hintLabel.setHorizontalAlignment(JLabel.CENTER);
		hintLabel.setBackground(Color.green);

		JLabel bestmoveLabel = gameBoardLabels[8][7];
		bestmoveLabel.setText("Best move");
		bestmoveLabel.setHorizontalAlignment(JLabel.CENTER);
		bestmoveLabel.setBackground(Color.magenta);
	}
	
	//Updates GUI using the GamePieceBoard[][] passed by Controller class 
	public void updateGUI(GamePieceBoard[][] gamePieceBoard, PieceColor playerTurn, int blackWins, int whiteWins) {
		for(int i = 0; i < 8; i++) {
			for(int j = 0; j < 8; j++) {
				if(gamePieceBoard[i][j] != null) {
				// Replace with Icon images of pieces
				if(gamePieceBoard[i][j].getColor()==PieceColor.WHITE){
					switch(gamePieceBoard[i][j].getName()){
						case KING: gameBoardLabels[i][j].setIcon(new ImageIcon(getClass().getResource("/resources/wking.png")));
							break;
						case KNIGHT: gameBoardLabels[i][j].setIcon(new ImageIcon(getClass().getResource("/resources/wknight.png")));
							break;
						case ROOK: gameBoardLabels[i][j].setIcon(new ImageIcon(getClass().getResource("/resources/wrook.png")));
							break;
						case BISHOP: gameBoardLabels[i][j].setIcon(new ImageIcon(getClass().getResource("/resources/wbishop.png")));
							break;
						case QUEEN: gameBoardLabels[i][j].setIcon(new ImageIcon(getClass().getResource("/resources/wqueen.png")));
							break;
						case PAWN: gameBoardLabels[i][j].setIcon(new ImageIcon(getClass().getResource("/resources/wpawn.png")));
							break;
					}
					
				}else if(gamePieceBoard[i][j].getColor()==PieceColor.BLACK){
					switch(gamePieceBoard[i][j].getName()){
						case KING: gameBoardLabels[i][j].setIcon(new ImageIcon(getClass().getResource("/resources/bking.png")));
							break;
						case KNIGHT: gameBoardLabels[i][j].setIcon(new ImageIcon(getClass().getResource("/resources/bknight.png")));
							break;
						case ROOK: gameBoardLabels[i][j].setIcon(new ImageIcon(getClass().getResource("/resources/brook.png")));
							break;
						case BISHOP: gameBoardLabels[i][j].setIcon(new ImageIcon(getClass().getResource("/resources/bbishop.png")));
							break;
						case QUEEN: gameBoardLabels[i][j].setIcon(new ImageIcon(getClass().getResource("/resources/bqueen.png")));
							break;
						case PAWN: gameBoardLabels[i][j].setIcon(new ImageIcon(getClass().getResource("/resources/bpawn.png")));
							break;
					}
				}
				gameBoardLabels[i][j].setHorizontalAlignment(SwingConstants.CENTER);
				}else{
					gameBoardLabels[i][j].setIcon(null);
				}	
		// Update the Panels located under the Chess board
		//...
			}
		}
	}
	
	//Adds ButtonListeners to all buttons. 
	public void addButtonListener(ActionListener listener) {
		//...
	}

	// Adds MouseListeners to all gameBoardLabels 
	public void addMouseListener(MouseListener listener) {
		for (int i = 0; i < 9; i++)
			for (int j = 0; j < 8; j++)
				gameBoardLabels[i][j].addMouseListener(listener);
	}
	
	// Highlighting
	public void highlightSelectedLabel(int sRow, int sCol, Color color) {
		gameBoardLabels[sRow][sCol].setBackground(color);
	}
	
	public void unHighlightSelectedLabel(int sRow, int sCol) {
		if ((sRow % 2 == 0 && sCol % 2 == 0) || (sRow % 2 != 0 && sCol % 2 != 0)) {
						gameBoardLabels[sRow][sCol].setBackground(Color.WHITE);
					} else {
						gameBoardLabels[sRow][sCol].setBackground(Color.GRAY);
					}
			
	}
	
	public JLabel[][] getGameBoardLabels() {
		return gameBoardLabels;
	}

	public void setgameBoardPieces(JLabel[][] gameBoardLabels) {
		this.gameBoardLabels = gameBoardLabels;
	}
}