package ia_MVC;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;


public class MainAI implements Runnable {

	public void run() {

		JFrame frame = new JFrame("Difficulty");
        frame.setSize(300, 150);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(3, 1));
        JLabel heading = new JLabel("Choose the difficulty: (0-20)");
		heading.setFont(new Font("Tahoma", Font.BOLD, 14));
		heading.setHorizontalAlignment(SwingConstants.CENTER);
		heading.setBackground(Color.getHSBColor(30f / 360f, 0.7f, 0.7f));
        JTextField text = new JTextField();

        JButton playbutton = new JButton("Play!");

		playbutton.addActionListener(new ActionListener() {
			@Override
			@SuppressWarnings("unused")
            public void actionPerformed(ActionEvent e) {
				String difficulty = text.getText();
				if(Integer.parseInt(difficulty)>=0 && Integer.parseInt(difficulty)<=20){
					Model gameModel = new Model();
					View gameView = new View();
					Controller gameController = new Controller(gameModel, gameView, difficulty);
					gameView.setVisible(true);
				}
				else{
					JFrame frame = new JFrame("error");
        			frame.setSize(300, 100);
					JPanel panel= new JPanel();
					JLabel errorLabel = new JLabel();
					errorLabel= new JLabel("Wrong number introduced!");
					errorLabel.setSize(300,100);
					errorLabel.setVerticalAlignment(SwingConstants.CENTER);
					panel.add(errorLabel);
					frame.add(panel);

					frame.setVisible(true);
				}
			}
		});

		mainPanel.add(heading);
		mainPanel.add(text);
		mainPanel.add(playbutton);

		frame.add(mainPanel);
		frame.setVisible(true);
		

	}
}
