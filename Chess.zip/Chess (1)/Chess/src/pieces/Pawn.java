package pieces;

public class Pawn extends GamePieceBoard {

	public Pawn(PieceColor color) {
		super(color);
	}

	@Override
	protected boolean isLegalPieceMove(int sRow, int sCol, int dRow, int dCol, GamePieceBoard[][] gamePieceBoard) {
	
		// Verifies wther the movement is formward (depending of the pawn color)
		if (gamePieceBoard[sRow][sCol].getColor() == PieceColor.WHITE) {
			// Standard forward movement
			if (dRow == sRow - 1 && dCol == sCol && gamePieceBoard[dRow][dCol] == null) {
				return true;
			}
			// Initial two squares movement
			else if (sRow == 6 && dRow == sRow - 2 && dCol == sCol && gamePieceBoard[dRow][dCol] == null) {
				return true;
			}
			// Diagonal capture
			else if (dRow == sRow - 1 && Math.abs(dCol - sCol) == 1 &&
					gamePieceBoard[dRow][dCol] != null && gamePieceBoard[dRow][dCol].getColor() == PieceColor.BLACK) {
				return true;
			}
		} else if (gamePieceBoard[sRow][sCol].getColor() == PieceColor.BLACK) {
			// Standard forward movement
			if (dRow == sRow + 1 && dCol == sCol && gamePieceBoard[dRow][dCol] == null) {
				return true;
			}
			// Initial two squares movement
			else if (sRow == 1 && dRow == sRow + 2 && dCol == sCol && gamePieceBoard[dRow][dCol] == null) {
				return true;
			}
			// Diagonal capture
			else if (dRow == sRow + 1 && Math.abs(dCol - sCol) == 1 &&
					gamePieceBoard[dRow][dCol] != null && gamePieceBoard[dRow][dCol].getColor() == PieceColor.WHITE) {
				return true;
			}
		}
	
		return false;
	}

	@Override
	public Piece getName() {
		return Piece.PAWN;
	}
}