package ia;

public class StockfishTest {
    public static void main(String[] args) {
        Stockfish client = new Stockfish();
        client.startEngine();
        System.out.println(client.setDifficuly("5"));

        client.drawBoard("nbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 4");
    }
}
