package multiplayer_MVC;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class Server {
	private static ConcurrentHashMap<String, MySocket> usuaris = new ConcurrentHashMap<>();
	private static Controller[] gameControllers = new Controller[2];

	public static void main(String[] args) {

		int port = 5000;
		MyServerSocket ss = new MyServerSocket(port);
		System.out.println("Servidor inciat.");

		while (true) {
			MySocket client = ss.accept();

			new Thread() {
				public void run() {
					client.write("Introdueix el teu nick: ");
					String nick = client.readLine();
					client.write("T'has connectat a la partida!");

					Model gameModel = new Model();
					View gameView = new View(nick);
					Controller gameController = new Controller(gameModel, gameView, client);
					saveController(gameController, nick);
					gameView.setVisible(true);

					addUsuari(nick, client);
					String text;
					while ((text=client.readLine()) != null) {
						gameController.playerMoves(text);
						broadcast(text, nick);
						System.out.println(nick + " moves: " + text);
					}
					removeUsuari(nick);
					client.close();

					
				}
			}.start();
		}
	}

	public static void addUsuari(String usuari, MySocket s) {
		System.out.println(usuari + " ha entrat a la partida");
		usuaris.put(usuari, s);
	}

	public static void removeUsuari(String usuari) {
		System.out.println(usuari + " ha sortit de la partida");
		usuaris.remove(usuari);
	}

	public static void broadcast(String missatge, String nick) {
		
		for (Map.Entry<String, MySocket> entry : usuaris.entrySet()) {
			MySocket socketActual = entry.getValue();
			System.out.println(nick+"= nick, "+entry.getKey()+"=Key");

			if(nick.contains("white") && entry.getKey().contains("black")){
				gameControllers[1].playerMoves(missatge);
				socketActual.write(nick + "> " + missatge);
			}

			if(nick.contains("black") && entry.getKey().contains("white")){
				gameControllers[0].playerMoves(missatge);
				socketActual.write(nick + "> " + missatge);
			}
			}
		}

	private static void saveController(Controller gameController, String nick) {
		if (nick.contains("white")){
			gameControllers[0] = gameController;
		}
		else
			gameControllers[1] = gameController;
	}
}
