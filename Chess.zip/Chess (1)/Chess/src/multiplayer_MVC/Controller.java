package multiplayer_MVC;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import ia.Stockfish;
import pieces.GamePieceBoard;
import pieces.PieceColor;


public class Controller {
	
	private Model gameModel;
	private View gameView;
	private GamePieceBoard[][] gamePieceBoard;
	private int tmpRow, tmpCol;
	private GamePieceBoard tmpPiece;
	private PieceColor playerTurn;
	private int blackWins, whiteWins;
	private Stockfish stockfish;
	MySocket client;
	//private Stockfish bmstockfish; 
	

	public Controller(Model gameModel, View gameView, MySocket client) {
		
		this.client= client;
		this.gameModel = gameModel;
		this.gameView = gameView;
		gamePieceBoard = gameModel.getGamePieceBoard();
		//gameBoardLabels = gameView.getGameBoardLabels();
		//selectedPiece = false;
		updatePlayerTurn();
		blackWins = 0;
		whiteWins = 0;
		//stockfish = new Stockfish();
		//stockfish.startEngine();
		//stdifficulty= Integer.parseInt(difficulty);
		//rndMoveCounter=0;
		this.gameView.updateGUI(gamePieceBoard, playerTurn, blackWins, whiteWins);
		this.gameView.addButtonListener(new ButtonHandler());
	}
	private class ButtonHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			playerMoves(gameView.getJText());
		}

	}

	public void turnmanage(int sRow, int sCol, GamePieceBoard tmpPiece){
		// Attempts to advance game by moving the selected piece
							if(gameModel.movePieceAttempt(tmpRow, tmpCol, sRow, sCol, tmpPiece)) {
								updatePlayerTurn();
								gameView.updateGUI(gamePieceBoard, playerTurn, blackWins, whiteWins);
							}
							
							gameView.unHighlightSelectedLabel(tmpRow, tmpCol);
							//selectedPiece = false;
							
							// Checks for GAMEOVER
							if(gameModel.isGameOver()) {
								PieceColor winner = PieceColor.BLACK;
								
								if(playerTurn == PieceColor.BLACK) {
									winner = PieceColor.WHITE;
									whiteWins++;
								} else
									blackWins++;
								
								JOptionPane.showMessageDialog(null,
								"Congratulations " + winner + ", you win!",
									    "WINNER!!!",
									    JOptionPane.PLAIN_MESSAGE);
								
								gameModel.resetGame();
								updatePlayerTurn();
								stockfish.stopEngine();
								gameView.updateGUI(gamePieceBoard, playerTurn, blackWins, whiteWins);
							}


	}

	public void playerMoves(String move){
			String[] s = move.split("");
			tmpRow= Integer.parseInt(s[0]);
			tmpCol= Integer.parseInt(s[1]);
			GamePieceBoard tmpPiece= gamePieceBoard[tmpRow][tmpCol];
			int dRow= Integer.parseInt(s[2]);
			int dCol= Integer.parseInt(s[3]);
			gamePieceBoard= gameModel.getGamePieceBoard();
			turnmanage(dRow,dCol,tmpPiece);
		}

	/* Updates the playerTurn to send to GUI */
	public void updatePlayerTurn() {
		playerTurn = gameModel.getPlayerTurn();
	}
}

