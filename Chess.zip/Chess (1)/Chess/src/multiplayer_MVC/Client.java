package multiplayer_MVC;

import java.io.*;

import ia.Stockfish;



public class Client{

	public static void main(String[] args){
		int port= 5000;
		MySocket s = new MySocket("localhost", port);  //host, port
		
		//Thread d'entrada
		new Thread(){
			public void run(){
				BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
				String missatge;
				try{
					while((missatge = in.readLine()) != null){
						s.write(missatge);
					}
					s.close();
				}catch(IOException ex){
					ex.printStackTrace();
				}
			}}.start();


		//Thread de sortida
		new Thread(){
			public void run(){
				String missatge;
				while((missatge = s.readLine()) != null){
					System.out.println(missatge); 
				}
			}}.start();
	}

}
