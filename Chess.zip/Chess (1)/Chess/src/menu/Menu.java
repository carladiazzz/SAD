package menu;

import javax.swing.*;

import ia_MVC.MainAI;
import local_MVC.Main;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Menu {
        public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("MENU");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(300, 200);

            JPanel panel = new JPanel(new BorderLayout());

            // Colors
            Color darkBlue = new Color(10, 134, 177); 

            panel.setBackground(Color.white);

            // Create components
            JLabel titleLabel = new JLabel("Chess");
            titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
            titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
            titleLabel.setForeground(darkBlue); // Texto en color verde oscuro
            titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));

            JButton button1 = new JButton("Local");
            JButton button2 = new JButton("Vs. AI");
            button1.setFont(new Font("Arial", Font.PLAIN, 16));
            button2.setFont(new Font("Arial", Font.PLAIN, 16));


            // Add components to the panel
            panel.add(titleLabel, BorderLayout.NORTH);
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
            buttonPanel.setBackground(Color.white); // Establecer el color de fondo del panel de botones
            buttonPanel.add(button1);
            buttonPanel.add(button2);
            panel.add(buttonPanel, BorderLayout.CENTER);

            frame.getContentPane().add(panel);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);

            // Add ActionListener to each button
            button1.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    SwingUtilities.invokeLater(new Main());
                }
            });

            button2.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    SwingUtilities.invokeLater(new MainAI());
                }
            });

            frame.setVisible(true);
        });
    } 


    
}
