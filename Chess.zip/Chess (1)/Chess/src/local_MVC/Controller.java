package local_MVC;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import pieces.GamePieceBoard;
import pieces.PieceColor;


public class Controller {
	
	private Model gameModel;
	private View gameView;
	private GamePieceBoard[][] gamePieceBoard;
	private JLabel[][] gameBoardLabels;
	private boolean selectedPiece;
	private int tmpRow, tmpCol;
	private GamePieceBoard tmpPiece;
	private PieceColor playerTurn;
	

	public Controller(Model gameModel, View gameView) {
		
		this.gameModel = gameModel;
		this.gameView = gameView;
		gamePieceBoard = gameModel.getGamePieceBoard();
		gameBoardLabels = gameView.getGameBoardLabels();
		selectedPiece = false;
		updatePlayerTurn();
		
		this.gameView.updateGUI(gamePieceBoard, playerTurn);

		this.gameView.addMouseListener(new MouseHandler());
	}

	
	private class MouseHandler implements MouseListener {

		public void mouseClicked(MouseEvent arg) {
		}

		public void mouseEntered(MouseEvent arg) {
		}

		public void mouseExited(MouseEvent arg) {
		}

		public void mousePressed(MouseEvent arg) {

			for(int i = 0; i < 8; i++) {
				for(int j = 0; j < 8; j++) {
					
					// Finds the Label that has been clicked
					if(gameBoardLabels[i][j] == arg.getSource()) {
						
						if(selectedPiece && tmpPiece != null) {	// SECOND CLICK to move the piece
							
							// Attempts to advance game by moving the selected piece
							if(gameModel.movePieceAttempt(tmpRow, tmpCol, i, j, tmpPiece)) {
								updatePlayerTurn();
								gameView.updateGUI(gamePieceBoard, playerTurn);
							}
							
							gameView.unHighlightSelectedLabel(tmpRow, tmpCol, tmpPiece.getColor());
							selectedPiece = false;
							
							// Checks for GAMEOVER
							if(gameModel.isGameOver()) {
								PieceColor winner = PieceColor.BLACK;
								
								if(playerTurn == PieceColor.BLACK) {
									winner = PieceColor.WHITE;
								}
							
								JOptionPane.showMessageDialog(null,
									    "Congratulations " + winner + ", you win!",
									    "WINNER!!!",
									    JOptionPane.PLAIN_MESSAGE);
								
								gameModel.resetGame();
								updatePlayerTurn();
								gameView.updateGUI(gamePieceBoard, playerTurn);
							}
								
						}else {	// Selects the clicked piece
							selectedPiece = true;
							tmpRow = i;
							tmpCol = j;
							tmpPiece = gamePieceBoard[i][j];
							
							gameView.highlightSelectedLabel(i, j);
						}
					}					
				}
			}
			
			// Resets the game if "Reset" is clicked
			if(arg.getSource() == gameBoardLabels[8][3]) {
				gameModel.resetGame();
				updatePlayerTurn();
				gameView.updateGUI(gamePieceBoard, playerTurn);
			} 
		}

		public void mouseReleased(MouseEvent arg) {
		}
	}

	/* Updates the playerTurn to send to GUI */
	public void updatePlayerTurn() {
		playerTurn = gameModel.getPlayerTurn();
	}
}