package menu;

import javax.swing.*;

import local_MVC.Main;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Menu {
        public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Menu");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(300, 300);

            JPanel mainPanel = new JPanel();
            mainPanel.setLayout(new GridLayout(3, 1));

            JButton button1 = new JButton("local");
            JButton button2 = new JButton("vs. AI");
            JButton button3 = new JButton("multiplayer");


            // Agregar ActionListener para el primer botón
            button1.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    SwingUtilities.invokeLater(new Main());
                }
            });

            // Agregar ActionListener para el segundo botón
            button2.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    JOptionPane.showMessageDialog(frame, "Haz clic en Botón 2");
                }
            });

            // Agregar ActionListener para el tercer botón
            button3.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    JOptionPane.showMessageDialog(frame, "Haz clic en Botón 2");
                }
            });

            mainPanel.add(button1);
            mainPanel.add(button2);
            mainPanel.add(button3);

            frame.add(mainPanel);
            frame.setVisible(true);
        });
    }


    
}
