package multiplayer_MVC;

import java.lang.*;
import java.io.*;
import java.util.*;

import pieces.GamePieceBoard;

/*
Aquesta classe serveix per crear un Client. Aquest, compta amb dos Threads; un que llegeix el text
per terminal i l'envia al servidor i un altre que rep els movimientos del servidor i els mostra per pantalla.
Per executar, es fa de la següent manera: java Client <host> <port>
*/

public class Client{

	public static void main(String[] args){
		MySocket s = new MySocket("localhost", 5000);  //host, port
		Model gameModel = new Model();
		View gameView = new View();
		@SuppressWarnings("unused")
		Controller gameController = new Controller(gameModel, gameView);
		gameView.setVisible(true);
		GamePieceBoard[][] gpb = gameModel.getGamePieceBoard();
		int sCol, sRow, dCol, dRow;


		//Thread d'entrada
		new Thread(){
			public void run(){
				BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
				String movimiento;
				try{
					while((movimiento = in.readLine()) != null){
						s.write(movimiento);
					}
					s.close();
				}catch(IOException ex){
					ex.printStackTrace();
				}
			}}.start();


		//Thread de sortida
		new Thread(){
			public void run(){
				String movimiento;
				while((movimiento = s.readLine()) != null){
					System.out.println(movimiento); 
					sRow= Character.getNumericValue(movimiento.charAt(1));
					sCol= Character.getNumericValue(movimiento.charAt(2));
					dRow= Character.getNumericValue(movimiento.charAt(4));
					dCol= Character.getNumericValue(movimiento.charAt(5));
					//gpb= gameModel.getGamePieceBoard();

					gameModel.movePieceAttempt(sRow,sCol,dRow,dCol,);
				}
			}}.start();
	}

}
