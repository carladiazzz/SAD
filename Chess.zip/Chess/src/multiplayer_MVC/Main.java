package multiplayer_MVC;


public class Main implements Runnable {

	public void run() {
		
		Model gameModel = new Model();
		View gameView = new View();
		
		@SuppressWarnings("unused")
		Controller gameController = new Controller(gameModel, gameView);
		
		gameView.setVisible(true);	
	}
}
