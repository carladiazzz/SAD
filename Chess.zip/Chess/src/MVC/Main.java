package MVC;


public class Main {

	public static void main(String[] args) {
		
		Model gameModel = new Model();
		View gameView = new View();
		
		@SuppressWarnings("unused")
		Controller gameController = new Controller(gameModel, gameView);
		
		gameView.setVisible(true);	
	}
}
