package pieces;

public class Queen extends GamePieceBoard {

	public Queen(PieceColor color) {
		super(color);
	}

	@Override
	protected boolean isLegalPieceMove(int sRow, int sCol, int dRow, int dCol, GamePieceBoard[][] gamePieceBoard) {
		// Check if Queen movement is legal
		if (isLegalLinearMove(sRow, sCol, dRow, dCol, gamePieceBoard) || isLegalDiagonalMove(sRow, sCol, dRow, dCol, gamePieceBoard))
			return true;
		else
			return false;
	}

	@Override
	public Piece getName() {
		return Piece.QUEEN;
	}
}