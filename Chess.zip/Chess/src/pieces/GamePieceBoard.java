package pieces;

public abstract class GamePieceBoard {

	private PieceColor color;
	
	// Check if legal move
	protected abstract boolean isLegalPieceMove(int sRow, int sCol, int dRow, 
			int dCol, GamePieceBoard[][] gamePieceBoard);

	public abstract Piece getName();	
	public GamePieceBoard(PieceColor color) {
		this.color = color;
	}
	
	// Returns the color of the GamePiece 
	public PieceColor getColor() { 
		return color;
	}
	
	// Checks if GamePiece is moving linearly 
	public boolean isLegalLinearMove(int sRow, int sCol, int dRow, int dCol, GamePieceBoard[][] gamePieceBoard) {
				    // Verifica que las coordenadas estén dentro del rango del tablero
					if (sRow < 0 || sRow >= gamePieceBoard.length || sCol < 0 || sCol >= gamePieceBoard[0].length ||
					dRow < 0 || dRow >= gamePieceBoard.length || dCol < 0 || dCol >= gamePieceBoard[0].length) {
					return false;
				}
			
				// Verifica si el movimiento es lineal (misma fila o misma columna)
				boolean isRowMove = sRow == dRow;
				boolean isColMove = sCol == dCol;
			
				if (!(isRowMove || isColMove)) {
					return false; // No es un movimiento lineal válido
				}
			
				// Verifica si hay piezas en el camino del movimiento lineal
				if (isRowMove) {
					int colIncrement = (dCol > sCol) ? 1 : -1;
			
					for (int currentCol = sCol + colIncrement; currentCol != dCol; currentCol += colIncrement) {
						if (gamePieceBoard[sRow][currentCol] != null) {
							return false; // Hay una pieza en el camino
						}
					}
				} else { // isColMove
					int rowIncrement = (dRow > sRow) ? 1 : -1;
			
					for (int currentRow = sRow + rowIncrement; currentRow != dRow; currentRow += rowIncrement) {
						if (gamePieceBoard[currentRow][sCol] != null) {
							return false; // Hay una pieza en el camino
						}
					}
				}
			
				return true; // Movimiento lineal válido sin piezas en el camino
	}
	
	// Checks if GamePiece is moving diagonally 
	public boolean isLegalDiagonalMove(int sRow, int sCol, int dRow, int dCol, GamePieceBoard[][] gamePieceBoard) {
		  // Verifica que las coordenadas estén dentro del rango del tablero
		  if (sRow < 0 || sRow >= gamePieceBoard.length || sCol < 0 || sCol >= gamePieceBoard[0].length ||
		  dRow < 0 || dRow >= gamePieceBoard.length || dCol < 0 || dCol >= gamePieceBoard[0].length) {
		  return false;
	  }
  
	  // Verifica si el movimiento es diagonal (misma diferencia absoluta entre filas y columnas)
	  int rowDifference = Math.abs(dRow - sRow);
	  int colDifference = Math.abs(dCol - sCol);
  
	  if (rowDifference != colDifference) {
		  return false; // No es un movimiento diagonal válido
	  }
  
	  // Verifica si hay piezas en el camino del movimiento diagonal
	  int rowIncrement = (dRow > sRow) ? 1 : -1;
	  int colIncrement = (dCol > sCol) ? 1 : -1;
  
	  for (int i = 1; i < rowDifference; i++) {
		  int currentRow = sRow + i * rowIncrement;
		  int currentCol = sCol + i * colIncrement;
  
		  if (gamePieceBoard[currentRow][currentCol] != null) {
			  return false; // Hay una pieza en el camino
		  }
	  }
  
	  return true; // Movimiento diagonal válido sin piezas en el camino
	}

	
	//Checks if GamePiece move is legal to make 
	public boolean isLegalMove(int sRow, int sCol, int dRow, int dCol, GamePieceBoard[][] gamePieceBoard) {
		
		GamePieceBoard destination = gamePieceBoard[dRow][dCol];
		
		// Check out-of-bounds, open/legit dest, and if isLegalPieceMove()
		if(dRow < 8 && dCol < 8 && dRow >= 0 && dCol >= 0 && 
				destination == null || color != destination.getColor())
			return isLegalPieceMove(sRow, sCol, dRow, dCol, gamePieceBoard);
		else
			return false;
	}

	public char getFENRepresentation(GamePieceBoard gamepiece){
		char piece=' ';
	if(color==PieceColor.WHITE){
		switch(getName()){
			case ROOK: piece='R'; break;
			case BISHOP: piece='B'; break;
			case KING: piece='K'; break;
			case QUEEN: piece='Q'; break;
			case KNIGHT: piece='N'; break;
			case PAWN: piece='P'; break;
		}
	}else{
		switch(getName()){
			case ROOK: piece='r'; break;
			case BISHOP: piece='b'; break;
			case KING: piece='k'; break;
			case QUEEN: piece='q'; break;
			case KNIGHT: piece='n'; break;
			case PAWN: piece='p'; break;
		}
	}
		return piece;
	}
}