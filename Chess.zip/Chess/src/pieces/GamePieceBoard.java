package pieces;

public abstract class GamePieceBoard {

	private PieceColor color;
	
	// Check if legal move
	protected abstract boolean isLegalPieceMove(int sRow, int sCol, int dRow, 
			int dCol, GamePieceBoard[][] gamePieceBoard);

	public abstract Piece getName();	
	public GamePieceBoard(PieceColor color) {
		this.color = color;
	}
	
	// Returns the color of the GamePiece 
	public PieceColor getColor() { 
		return color;
	}
	
	// Checks if GamePiece is moving linearly 
	public boolean isLegalLinearMove(int sRow, int sCol, int dRow, 
			int dCol, GamePieceBoard[][] gamePieceBoard) {
				return true;
	}
	
	// Checks if GamePiece is moving diagonally 
	public boolean isLegalDiagonalMove(int sRow, int sCol, int dRow, int dCol, GamePieceBoard[][] gamePieceBoard) {
		return true;
	}
	
	//Checks if GamePiece move is legal to make 
	public boolean isLegalMove(int sRow, int sCol, int dRow, int dCol, GamePieceBoard[][] gamePieceBoard) {
		
		GamePieceBoard destination = gamePieceBoard[dRow][dCol];
		
		// Check out-of-bounds, open/legit dest, and if isLegalPieceMove()
		if(dRow < 8 && dCol < 8 && dRow >= 0 && dCol >= 0 && 
				destination == null || color != destination.getColor())
			return isLegalPieceMove(sRow, sCol, dRow, dCol, gamePieceBoard);
		else
			return false;
	}
}