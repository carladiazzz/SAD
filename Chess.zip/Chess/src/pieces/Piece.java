package pieces;

public enum Piece {
	KING, QUEEN, BISHOP, KNIGHT, ROOK, PAWN;
}
