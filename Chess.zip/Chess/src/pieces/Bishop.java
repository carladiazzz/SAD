package pieces;

public class Bishop extends GamePieceBoard {

	public Bishop(PieceColor color) {
		super(color);
	}

	@Override
	protected boolean isLegalPieceMove(int sRow, int sCol, int dRow, int dCol, GamePieceBoard[][] gamePieceBoard) {
		return gamePieceBoard[sRow][sCol].isLegalDiagonalMove(sRow, sCol, dRow, dCol, gamePieceBoard);
	}

	@Override
	public Piece getName() {
		return Piece.BISHOP;
	}
}