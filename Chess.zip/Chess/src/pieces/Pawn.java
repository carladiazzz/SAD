package pieces;

public class Pawn extends GamePieceBoard {

	public Pawn(PieceColor color) {
		super(color);
	}

	@Override
	protected boolean isLegalPieceMove(int sRow, int sCol, int dRow, int dCol, GamePieceBoard[][] gamePieceBoard) {
		return true;
	}

	@Override
	public Piece getName() {
		return Piece.PAWN;
	}
}