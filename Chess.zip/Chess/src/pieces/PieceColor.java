package pieces;

public enum PieceColor {
	BLACK, WHITE;
}
