package stockfish_MVC;

import gameboard.GameBoard;
import pieces.GamePieceBoard;
import pieces.Piece;
import pieces.PieceColor;
import ia.Stockfish;

public class Model {

	private String FEN;
	private GameBoard board;
	private GamePieceBoard[][] gamePieceBoard;
	private PieceColor playerTurn;
	private Controller controller;
	private Stockfish stockfish;
	
	public Model() {
		setBoard(new GameBoard());
		gamePieceBoard = board.getBoard();
		playerTurn = PieceColor.WHITE;
		stockfish = new Stockfish();
		stockfish.startEngine();
		FEN= "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
	}

	//Tries to move a GamePiece and returns true if it's possible
	public boolean movePieceAttempt(int sRow, int sCol, int dRow, 
			int dCol, GamePieceBoard piece) {
	if(playerTurn==PieceColor.WHITE){
		if(piece.isLegalMove(sRow, sCol, dRow, dCol, gamePieceBoard) && piece.getColor() == playerTurn) {
			// Advance game
			gamePieceBoard[dRow][dCol] = gamePieceBoard[sRow][sCol];
			gamePieceBoard[sRow][sCol] = null;
			// ActualFEN
			System.out.println("FEN: "+FEN);
			updateFEN(gamePieceBoard);
			changePlayerTurn();
			iaturn();
			return true;
		}
	}else{
		gamePieceBoard[dRow][dCol] = gamePieceBoard[sRow][sCol];
		gamePieceBoard[sRow][sCol] = null;
		updateFEN(gamePieceBoard);
		changePlayerTurn();
	}		
		
		return false;
	}
	
	//Reset Game to starting position 
	public void resetGame() {
		playerTurn = PieceColor.WHITE;
		board.resetBoard();
	}
	
	// Changes playerTurn using PieceColor enum 
	public void changePlayerTurn() {
		if(playerTurn == PieceColor.WHITE){
			playerTurn = PieceColor.BLACK;
		}
		else
			playerTurn = PieceColor.WHITE;
	}
	
	// Checks if game is over 
	public boolean isGameOver() {
		int count = 0;
		
		for(int i = 0; i < 8; i++)
			for(int j = 0; j < 8; j++)
				if(gamePieceBoard[i][j] != null && gamePieceBoard[i][j].getName() == Piece.KING)
					count++;
		
		if(count != 2)
			return true;
		
		return false;
	}

	private void iaturn(){
		System.out.println(FEN);
		String bestmove= stockfish.getBestMove(FEN, 100);
		String[] s = bestmove.split("");
		int sRow= Integer.parseInt(s[0]);
		int sCol= Integer.parseInt(s[1]);
		int dRow= Integer.parseInt(s[2]);
		int dCol= Integer.parseInt(s[3]);
		controller.turnmanage(sRow,sCol,getGamePieceBoard()[dRow][dCol]);
	}

	public void updateFEN(GamePieceBoard[][] gamePieceBoard){
		StringBuilder fenBuilder = new StringBuilder();

    // 1. Agregar la posición de las piezas en el tablero
    for (int row = 7; row >= 0; row--) {
        int emptyCount = 0;
        for (int col = 0; col < 8; col++) {
            char pieceChar = (gamePieceBoard[row][col] != null) ? gamePieceBoard[row][col].getFENRepresentation(gamePieceBoard[row][col]) : ' ';

            if (pieceChar == ' ') {
                emptyCount++;
            } else {
                if (emptyCount > 0) {
                    fenBuilder.append(emptyCount);
                    emptyCount = 0;
                }
                fenBuilder.append(pieceChar);
            }
        }

        if (emptyCount > 0) {
            fenBuilder.append(emptyCount);
        }

        if (row > 0) {
            fenBuilder.append('/');
        }
    }

    // 2. Agregar información de turno y enroque
    fenBuilder.append(" b - - 0 1"); // Negras, sin enroque, sin captura al paso, medio movimientos y total de movimientos

    // Imprimir el FEN actualizado
    System.out.println("FEN: " + fenBuilder.toString());

    // Guardar el FEN actualizado en la variable de clase
    FEN = fenBuilder.toString();
        // 2. Agregar información de turno y enroque
        fenBuilder.append(" b - - 0 1"); // Negras, sin enroque, sin captura al paso, medio movimientos y total de movimientos

        // Imprimir el FEN actualizado
        System.out.println("FEN: " + fenBuilder.toString());


		// Convertir la posición del tablero a FEN
		/*for (int i = 7; i >= 0; i--) {
			int emptyCount = 0;
	
			for (int j = 0; j < 8; j++) {
				char pieceChar = (gamePieceBoard[i][j] != null) ? gamePieceBoard[i][j].getFENRepresentation(gamePieceBoard[i][j]) : ' ';
	
				if (pieceChar == ' ') {
					emptyCount++;
				} else {
					if (emptyCount > 0) {
						fenBuilder.append(emptyCount);
						emptyCount = 0;
					}
					fenBuilder.append(pieceChar);
				}
			}
	
			if (emptyCount > 0) {
				fenBuilder.append(emptyCount);
				emptyCount = 0;
			}
	
			if (i > 0) {
				fenBuilder.append('/');
			}
		}
	
		// Otras partes del FEN
		fenBuilder.append(' ');
	
		// Jugador activo
		fenBuilder.append((playerTurn == PieceColor.WHITE) ? 'w' : 'b');
	
		// Enroques (por ahora asumimos que no hay enroques)
		fenBuilder.append(" -");
	
		// Captura al paso (por ahora asumimos que no hay captura al paso)
		fenBuilder.append(" -");
	
		// Contador de medio movimientos y número total de movimientos (por ahora asumimos que ambos son 0)
		fenBuilder.append(" 0 0");
	
		// FEN completo
		FEN = fenBuilder.toString();*/
	}


	
	public GameBoard getBoard() {
		return board;
	}

	public void setBoard(GameBoard board) {
		this.board = board;
	}
	
	public GamePieceBoard[][] getGamePieceBoard() {
		return board.getBoard();
	}
	
	public PieceColor getPlayerTurn() {
		return playerTurn;
	}
}