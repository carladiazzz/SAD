package stockfish_MVC;

import gameboard.GameBoard;
import pieces.GamePieceBoard;
import pieces.Piece;
import pieces.PieceColor;
import ia.Stockfish;

public class Model {

	private String FEN;
	private GameBoard board;
	private GamePieceBoard[][] gamePieceBoard;
	private PieceColor playerTurn;
	Stockfish client;
	
	public Model() {
		setBoard(new GameBoard());
		gamePieceBoard = board.getBoard();
		playerTurn = PieceColor.WHITE;
		client = new Stockfish();
		FEN= "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
	}

	//Tries to move a GamePiece and returns true if it's possible
	public boolean movePieceAttempt(int sRow, int sCol, int dRow, 
			int dCol, GamePieceBoard piece) {
	if(playerTurn==PieceColor.WHITE){
		if(piece.isLegalMove(sRow, sCol, dRow, dCol, gamePieceBoard) && piece.getColor() == playerTurn) {
			// Advance game
			gamePieceBoard[dRow][dCol] = gamePieceBoard[sRow][sCol];
			gamePieceBoard[sRow][sCol] = null;
			// ActualFEN
			updateFEN(gamePieceBoard);
			changePlayerTurn();
			return true;
		}
	}else{
		//ActualFEN
		updateFEN(gamePieceBoard);
		String bestmove= client.getBestMove(FEN, 100);
		

	}		
		
		return false;
	}
	
	//Reset Game to starting position 
	public void resetGame() {
		playerTurn = PieceColor.WHITE;
		board.resetBoard();
	}
	
	// Changes playerTurn using PieceColor enum 
	public void changePlayerTurn() {
		if(playerTurn == PieceColor.WHITE)
			playerTurn = PieceColor.BLACK;
		else
			playerTurn = PieceColor.WHITE;
	}
	
	// Checks if game is over 
	public boolean isGameOver() {
		int count = 0;
		
		for(int i = 0; i < 8; i++)
			for(int j = 0; j < 8; j++)
				if(gamePieceBoard[i][j] != null && gamePieceBoard[i][j].getName() == Piece.KING)
					count++;
		
		if(count != 2)
			return true;
		
		return false;
	}

	public void updateFEN(GamePieceBoard[][] gamePieceBoard){
		StringBuilder fenBuilder = new StringBuilder();

		// Convertir la posición del tablero a FEN
		for (int i = 7; i >= 0; i--) {
			int emptyCount = 0;
	
			for (int j = 0; j < 8; j++) {
				char pieceChar = (gamePieceBoard[i][j] != null) ? gamePieceBoard[i][j].getFENRepresentation(gamePieceBoard[i][j]) : ' ';
	
				if (pieceChar == ' ') {
					emptyCount++;
				} else {
					if (emptyCount > 0) {
						fenBuilder.append(emptyCount);
						emptyCount = 0;
					}
					fenBuilder.append(pieceChar);
				}
			}
	
			if (emptyCount > 0) {
				fenBuilder.append(emptyCount);
				emptyCount = 0;
			}
	
			if (i > 0) {
				fenBuilder.append('/');
			}
		}
	
		// Otras partes del FEN
		fenBuilder.append(' ');
	
		// Jugador activo
		fenBuilder.append((playerTurn == PieceColor.WHITE) ? 'w' : 'b');
	
		// Enroques (por ahora asumimos que no hay enroques)
		fenBuilder.append(" -");
	
		// Captura al paso (por ahora asumimos que no hay captura al paso)
		fenBuilder.append(" -");
	
		// Contador de medio movimientos y número total de movimientos (por ahora asumimos que ambos son 0)
		fenBuilder.append(" 0 0");
	
		// FEN completo
		FEN = fenBuilder.toString();
	}
	
	public GameBoard getBoard() {
		return board;
	}

	public void setBoard(GameBoard board) {
		this.board = board;
	}
	
	public GamePieceBoard[][] getGamePieceBoard() {
		return board.getBoard();
	}
	
	public PieceColor getPlayerTurn() {
		return playerTurn;
	}
}